package item

import data.item.allow_create

import rego.v1

# Default deny policy
